export const cards = [
  {
    product_name: "Wall of Cloud Design",
    thubnail: "/images/home1.png",
    product_card_colors: ["#fa782e", "#c82930"],
    created_at: '5 March 2024',
  },
  {
    product_name: "Wall of Cloud Design",
    thubnail: "/images/home2.png",
    product_card_colors: ["#5D1D88", "#FFB700"],
    created_at: '5 March 2024',
  },
  {
    product_name: "Wall of Cloud Design",
    thubnail: "/images/home3.png",
    product_card_colors: ["#5D1D88", "#FFB700"],
    created_at: '5 March 2024',
  },
  {
    product_name: "Wall of Cloud Design",
    thubnail: "/images/home1.png",
    product_card_colors: ["#fa782e", "#c82930"],
    created_at: '5 March 2024',
  },
  {
    product_name: "Wall of Cloud Design",
    thubnail: "/images/home2.png",
    product_card_colors: ["#5D1D88", "#FFB700"],
    created_at: '5 March 2024',
  },
  {
    product_name: "Wall of Cloud Design",
    thubnail: "/images/home3.png",
    product_card_colors: ["#5D1D88", "#FFB700"],
    created_at: '5 March 2024',
  },
];
